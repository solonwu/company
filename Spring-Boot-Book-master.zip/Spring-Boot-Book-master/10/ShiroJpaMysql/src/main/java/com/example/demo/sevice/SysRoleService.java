package com.example.demo.sevice;

import com.example.demo.entity.SysRole;
/**
 * @author longzhonghua
 * @data 2/23/2019 1:42 PM
 */
public interface SysRoleService {
    public SysRole findByRole(String role);
}
