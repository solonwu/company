package com.example.demo.service;

/**
 * Copyright (C), 2019-2019, XXX有限公司
 * FileName: UserService
 * Author:   longzhonghua
 * Date:     2019/5/7 10:44
 * Description:
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
public interface UserService {
    public String addUser();
    public String updateUser() ;
    public String deleteUser() ;
}
