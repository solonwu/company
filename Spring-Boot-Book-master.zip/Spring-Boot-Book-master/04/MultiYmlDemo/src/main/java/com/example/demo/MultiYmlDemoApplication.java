package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiYmlDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiYmlDemoApplication.class, args);
	}

}
